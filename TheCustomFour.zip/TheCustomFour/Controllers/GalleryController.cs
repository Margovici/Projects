﻿using Microsoft.AspNetCore.Mvc;

namespace Test.Controllers
{
    public class GalleryController : Controller
    {
        public IActionResult Gallery()
        {
            return View();
        }
    }
}
