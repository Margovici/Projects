﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Test.Data;
using Test.Models;
using Test.Models.Domain;
using System.Text.Json;
using Microsoft.AspNetCore.Http;

namespace Test.Controllers
{
    public class UserController : Controller
    {
        private readonly TheCustomFourDbContext _dbContext;

        public UserController(TheCustomFourDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        // GET: /User/Signin
        [HttpGet]
        public IActionResult Signin()
        {
            return View("~/Views/User/Signin.cshtml");
        }

        // POST: /User/Signin
        [HttpPost]
        public async Task<IActionResult> Signin(SigninViewModels model)
        {
            if (!ModelState.IsValid)
            {
                return View("~/Views/User/Signin.cshtml", model);
            }

            var newUser = new User
            {
                Name = model.Name,
                UserName = model.UserName,
                Email = model.Email,
                Password = model.Password,
                Phone = model.Phone,
                Address = model.Address,
                PostCode = model.PostCode,
                CreateTime = DateTime.Now
            };

            await _dbContext.Users.AddAsync(newUser);
            await _dbContext.SaveChangesAsync();

            TempData["SuccessMessage"] = "Account created successfully!";
            return RedirectToAction("Login");
        }

        // GET: /User/Login
        [HttpGet]
        public IActionResult Login()
        {
            return View("~/Views/User/Login.cshtml");
        }

        // POST: /User/Login
        [HttpPost]
        public async Task<IActionResult> Login(string email, string password)
        {
            // 1. Validate the user (e.g., search in the database)
            var user = await _dbContext.Users
                .FirstOrDefaultAsync(u => u.Email == email && u.Password == password);
            if (user == null)
            {
                ViewBag.Error = "Invalid credentials";
                return View("~/Views/User/Login.cshtml");
            }

            // 2. Create claims and authenticate the user
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.Name),
                new Claim(ClaimTypes.Email, user.Email)
            };
            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

            // 3. Redirect to profile or home
            return RedirectToAction("Profile", "User");
        }

        // GET: /User/Dashboard
        [HttpGet]
        public IActionResult Dashboard()
        {
            var email = HttpContext.Session.GetString("UserEmail");
            if (string.IsNullOrEmpty(email))
                return RedirectToAction("Login");

            ViewBag.UserEmail = email;
            ViewBag.UserName = HttpContext.Session.GetString("UserName");

            return View("~/Views/User/Dashboard.cshtml");
        }

        // GET: /User/Logout
        [HttpGet]
        public async Task<IActionResult> Logout()
        {
            // Dacă folosești autentificare cu cookie
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }

        // GET: /User/Profile
        [HttpGet]
        public IActionResult Profile()
        {
            var email = User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value;
            if (string.IsNullOrEmpty(email))
                return RedirectToAction("Login");

            var user = _dbContext.Users.FirstOrDefault(u => u.Email == email);
            if (user == null)
                return RedirectToAction("Login");

            var model = new UserViewModel
            {
                Name = user.Name,
                UserName = user.UserName,
                Email = user.Email,
                Address = user.Address,      // asigură-te că ai această linie
                PostCode = user.PostCode,    // asigură-te că ai această linie
                Phone = user.Phone           // asigură-te că ai această linie
            };

            return View("~/Views/User/Profile.cshtml", model);
        }

        // GET: /User/ForgotPassword
        [HttpGet]
        public IActionResult ForgotPassword()
        {
            return View("~/Views/User/ForgotPassword.cshtml");
        }

        // POST: /User/ForgotPassword
        [HttpPost]
        public async Task<IActionResult> ForgotPassword(string email)
        {
            // Exemplu simplu: verifică dacă emailul există
            var user = await _dbContext.Users.FirstOrDefaultAsync(u => u.Email == email);
            if (user == null)
            {
                ViewBag.Error = "No account found with this email.";
                return View("~/Views/User/ForgotPassword.cshtml");
            }

            // Generează cod random de 4 cifre
            var random = new Random();
            var code = random.Next(1000, 9999).ToString();

            // Salvează codul și emailul în sesiune
            HttpContext.Session.SetString("ResetCode", code);
            HttpContext.Session.SetString("ResetEmail", email);

            // Trimite codul în ViewBag pentru pop-up (doar pentru demo, în realitate se trimite pe email)
            ViewBag.ShowCodePopup = true;
            ViewBag.ResetCode = code;

            return View("~/Views/User/ForgotPassword.cshtml");
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UpdateProfile(UserViewModel model)
        {
           
            var email = User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value;
            if (string.IsNullOrEmpty(email))
                return RedirectToAction("Login");

            var user = _dbContext.Users.FirstOrDefault(u => u.Email == email);
            if (user == null)
            {
                TempData["Error"] = "Utilizatorul nu a fost găsit.";
                return View("Profile", model);
            }

            // Actualizează doar câmpurile editabile
            user.Address = model.Address;
            user.PostCode = model.PostCode;
            user.Phone = model.Phone;
            user.Name = model.Name; // Asigură-te că ai această linie pentru a actualiza numele
            user.UserName= model.UserName;
            user.Email = model.Email; // Asigură-te că ai această linie pentru a actualiza emailul


            _dbContext.SaveChanges();

            TempData["Success"] = "Profilul a fost actualizat cu succes!";
            return RedirectToAction("Profile");
        }
        [HttpGet]
        public IActionResult ChangePassword()
        {
            return View("~/Views/User/ChangePassword.cshtml");
        }

        [HttpPost]
        public async Task<IActionResult> ChangePassword(string newPassword, string confirmPassword)
        {
            if (newPassword != confirmPassword)
            {
                ViewBag.Error = "Passwords do not match.";
                return View("~/Views/User/ChangePassword.cshtml");
            }

            var email = HttpContext.Session.GetString("ResetEmail");
            var user = await _dbContext.Users.FirstOrDefaultAsync(u => u.Email == email);
            if (user == null)
            {
                ViewBag.Error = "User not found.";
                return View("~/Views/User/ChangePassword.cshtml");
            }

            user.Password = newPassword;
            await _dbContext.SaveChangesAsync();

            // Șterge codul și emailul din sesiune
            HttpContext.Session.Remove("ResetCode");
            HttpContext.Session.Remove("ResetEmail");

            ViewBag.PasswordChanged = true;
            return View("~/Views/User/ChangePassword.cshtml");
        }

        [HttpPost]
        public IActionResult VerifyResetCode(string enteredCode)
        {
            var code = HttpContext.Session.GetString("ResetCode");
            if (enteredCode == code)
            {
                // Redirecționează către ChangePassword
                return RedirectToAction("ChangePassword");
            }
            ViewBag.Error = "Invalid code.";
            return View("ForgotPassword");
        }


        [Authorize]
        [HttpGet]
        public IActionResult MyCart()
        {
            var email = User.FindFirst(ClaimTypes.Email)?.Value;
            var user = _dbContext.Users.FirstOrDefault(u => u.Email == email);
            var cartItems = _dbContext.Orders
                .Where(o => o.UserName == user.UserName /* && o.Status == "InCart" */)
                .ToList();

            return View(cartItems); // View-ul MyCart.cshtml
        }


        [Authorize]
        [HttpPost]
        public IActionResult BuyNow(int orderId)
        {
            TempData["OrderId"] = orderId;
            return RedirectToAction("Payment");
        }

        [Authorize]
        [HttpGet]
        public IActionResult Payment()
        {
            return View();
        }

        [Authorize]
        [HttpPost]
        public IActionResult Payment(int orderId, string paymentMethod, string CardNumber, string CardHolderName, string ExpirationDate, string CVV)
        {
            var order = _dbContext.Orders.FirstOrDefault(o => o.Id == orderId);
            if (order == null)
                return RedirectToAction("MyCart");

            if (paymentMethod == "Card")
            {
                var payment = new Payment
                {
                    PaymentMethod = "Card",
                    CardNumber = CardNumber,
                    CardHolderName = CardHolderName,
                    ExpirationDate = DateTime.Parse(ExpirationDate),
                    CVV = CVV,
                    Amount = 0, // setează suma corectă
                    PaymentDate = DateTime.Now
                };
                _dbContext.Payments.Add(payment);
            }
            // Pentru ramburs nu salvezi date card

            // Marchează comanda ca finalizată (poți adăuga un status)
            // order.Status = "Completed";
            _dbContext.SaveChanges();

            TempData["Success"] = "Bought successfully!";
            return RedirectToAction("OrderSuccess");
        }
        [HttpPost]
        public IActionResult AddToCart(string Color, string Interior, string Wheels)
        {

            if (!User.Identity.IsAuthenticated)
            {
                // Redirecționează la login cu returnUrl
                return RedirectToAction("Login", "User", new { returnUrl = Url.Action("CustomizeAudi", "Model") });
            }
            // Preia coșul din sesiune ca string
            var cartString = HttpContext.Session.GetString("CartList");
            var cartList = new List<string>();

            if (!string.IsNullOrEmpty(cartString))
                cartList = new List<string>(cartString.Split(';', StringSplitOptions.RemoveEmptyEntries));

            // Adaugă produsul curent ca string concatenat
            cartList.Add($"{Color}|{Interior}|{Wheels}");

            // Salvează lista în sesiune ca string cu separator ;
            HttpContext.Session.SetString("CartList", string.Join(';', cartList));

            TempData["showSuccess"] = true;
            return RedirectToAction("CustomizeAudi", "Model");

        }
    }
}
