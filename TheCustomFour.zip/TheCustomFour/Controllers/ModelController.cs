﻿using Microsoft.AspNetCore.Mvc;

namespace Test.Controllers
{
    public class ModelController : Controller
    {
        public IActionResult Model()
        {
            return View();
        }

        public IActionResult CustomizeAudi()
        {
            return View();
        }

        public IActionResult CustomizeMercedes()
        {
            return View();
        }

        public IActionResult CustomizePorsche()
        {
            return View();
        }
    }
}
