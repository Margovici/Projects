﻿namespace Test.Models
{
    public class UserViewModel
    {
        public string Name { get; set; }
        public string Email { get; set; }
        // Adaugă aici alte proprietăți necesare
    }
}