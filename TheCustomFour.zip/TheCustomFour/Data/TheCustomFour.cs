﻿using Microsoft.EntityFrameworkCore;
using Test.Models.Domain;

namespace Test.Data
{
    public class TheCustomFourDbContext : DbContext
    {
        public TheCustomFourDbContext(DbContextOptions options) : base(options) { }
        public DbSet<User> Users { get; set; }
        public DbSet<Orders> Orders { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<Model>Models { get; set; } 

    }
}
