﻿using System.ComponentModel.DataAnnotations;
namespace Test.Models.Domain
{
    public class Model
    {
        [Key]
        public int Id { get; set; }
        public string Brand { get; set; }
        public string ModelName { get; set; }
        public string Color { get; set; }
        public string ColorUrl { get; set; }
        public string Jante { get; set; }
        public string JanteUrl { get; set; }
        public string Interior { get; set; }
        public string InteriorUrl { get; set; }
        public string Price { get; set; }
        public string ImageUrl { get; set; }
    }
}
