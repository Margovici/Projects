﻿using System.ComponentModel.DataAnnotations;

public class Orders
{
    [Key]
    public int Id { get; set; }
    public string OrderNumber { get; set; }
    public string UserName { get; set; }
    public string CarDetails { get; set; }
    public DateTime OrderDate { get; set; }
}